from guacapy.client import Guacamole
from guacapy.templates import *
